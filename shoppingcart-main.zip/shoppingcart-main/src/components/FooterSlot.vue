<template>
   <footer>
    <slot name="footer"></slot>
  </footer>
</template>

