<template>
  <div class="pagenotfnd">
        <h1>404 Page not 
            Found
        </h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>
.pagenotfnd{
    width:100%;
    height:200px;
    background-color: beige;
    text-align: center;
    align-items: center;
    color: blueviolet;
}
</style>